English-and-Persian-Lorem-Ipsum-Extension-for-Sketch - Version 3.1

=============================

This is an extension for creating english & persian(farsi) Lorem Ipsum text in Sketch.

<pre>
لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است و برای شرایط فعلی تکنولوژی مورد نیاز و کاربردهای متنوع با هدف بهبود ابزارهای کاربردی می باشد. کتابهای زیادی در شصت و سه درصد گذشته، حال و آینده شناخت فراوان جامعه و متخصصان را می طلبد تا با نرم افزارها شناخت بیستری را برای طراحان رایانه ای و فرهنگ پیشرو در زبان فارسی ایجاد کرد. در این صورت می توان امید داشت که تمام و دشواری موجود در ارائه راهکارها و شرایط سخت تایپ به پایان رسد وزمان مورد نیاز شامل حروفچینی دستاوردهای اصلی و جوابگوی سوالات پیوسته اهل دنیای موجود طراحی اساسا مورد استفاده قرار گیرد.
</pre>
<pre>
Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
</pre>

Installation
=============================
<ol>
  <li>Download and open <code>english-and-persian-lorem-ipsum-master.zip</code></li>
  <li>Double click on <code>Enlgish & Persian Lorem Ipsum.sketchplugin</code> file</li>
  <li>That's it...</li>
</ol>

Also you can use sketch toolbox application for install plugins : http://sketchtoolbox.com

Usage
=============================

Select any text in Sketch and hit

- ( ⌥ ⌘ [ ) to generate english lorem ipsum.
- ( ⌥ ⌘ ] ) to generate persian lorem ipsum.

or use 'Lorem Ipsum Generator' from Plugins menu.

Feedback
=============================

If you discover any issues , please send a message to me@rezamahmoudi.ir or find me on twitter @rezamahmoudii
